import "./App.css";

import AppStore from './components/AppStore'
function App() {
  return (
    <div className="App">
    <AppStore/>
    </div>
  );
}

export default App;
